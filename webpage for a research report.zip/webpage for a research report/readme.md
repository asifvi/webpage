<p>
    This is the report by HTML,CSS,JS and Highchart for chart.
</p>
<h1>
    <a href="https://web-report-dashboard.netlify.app/">Live Preview</a>
</h1>